package com.example.voiceassistant

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var speechLauncher: ActivityResultLauncher<Intent>
    private lateinit var permissionLauncher: ActivityResultLauncher<Array<String>>
    private var isTtsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Initialize modern ActivityResultLauncher for Speech Recognizer
        speechLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val spokenText = matches?.firstOrNull()?.trim()
                if (!spokenText.isNullOrEmpty()) {
                    handleVoiceCommand(spokenText.lowercase(Locale("hi", "IN")))
                }
            } else {
                Toast.makeText(this, "आवाज़ नहीं पहचानी गई (No speech recognized)", Toast.LENGTH_SHORT).show()
            }
        }

        // 2. Initialize runtime permission launcher
        permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissionsMap ->
            val micGranted = permissionsMap[Manifest.permission.RECORD_AUDIO] ?: false
            if (micGranted) {
                startListening()
            } else {
                Toast.makeText(
                    this,
                    "वॉयस असिस्टेंट के लिए माइक्रोफोन की अनुमति आवश्यक है।",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        // 3. Initialize Hindi Text-to-Speech engine
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val hindiLocale = Locale("hi", "IN")
            val result = tts.setLanguage(hindiLocale)

            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to Indian English if Hindi voice data is missing on device
                tts.setLanguage(Locale("en", "IN"))
            }

            isTtsReady = true

            // Set TTS Progress Listener
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "initial_greeting") {
                        runOnUiThread { checkPermissionsAndListen() }
                    }
                }
                override fun onError(utteranceId: String?) {}
            })

            speak("नमस्ते, मैं आपकी क्या मदद कर सकती हूँ?", "initial_greeting")
        } else {
            Toast.makeText(this, "TTS initialization failed", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Speaks text using Android TextToSpeech engine
     */
    private fun speak(text: String, utteranceId: String = "assistant_reply") {
        if (isTtsReady && ::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    /**
     * Checks all dangerous runtime permissions before launching speech recognition
     */
    fun checkPermissionsAndListen() {
        val requiredPermissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CAMERA
        )

        val ungranted = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (ungranted.isNotEmpty()) {
            permissionLauncher.launch(ungranted.toTypedArray())
        } else {
            startListening()
        }
    }

    /**
     * Launches the Speech Recognition Intent with Hindi Language Model
     */
    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए... मैं सुन रही हूँ")
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-IN", "hi-Latn"))
        }

        try {
            speechLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "डिवाइस में स्पीच रिकग्निशन उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Action Router: Dispatches user commands to specific Android Intents
     */
    private fun handleVoiceCommand(command: String) {
        when {
            // --- 1. YOUTUBE INTENT ---
            command.contains("youtube") || command.contains("यूट्यूब") || command.contains("गाने") -> {
                speak("यूट्यूब खोल रही हूँ")
                val youtubeIntent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (youtubeIntent != null) {
                    startActivity(youtubeIntent)
                } else {
                    // Fallback to browser YouTube URL
                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                    startActivity(webIntent)
                }
            }

            // --- 2. GOOGLE MAPS NAVIGATION ---
            command.contains("map") || command.contains("मैप") || command.contains("रास्ता") || command.contains("कहाँ है") -> {
                val destination = command
                    .replace("मैप", "").replace("रास्ता", "").replace("दिखाओ", "")
                    .replace("maps", "").trim()

                speak("$destination का रास्ता दिखा रही हूँ")
                val gmmIntentUri = Uri.parse("geo:0,0?q=${Uri.encode(if (destination.isNotEmpty()) destination else "Delhi")}")
                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                    setPackage("com.google.android.apps.maps")
                }
                try {
                    startActivity(mapIntent)
                } catch (e: Exception) {
                    // Fallback generic geo view
                    startActivity(Intent(Intent.ACTION_VIEW, gmmIntentUri))
                }
            }

            // --- 3. CAMERA INTENT ---
            command.contains("camera") || command.contains("कैमरा") || command.contains("फोटो") -> {
                speak("कैमरा खोल रही हूँ")
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                try {
                    startActivity(cameraIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "कैमरा खोलने में असमर्थ", Toast.LENGTH_SHORT).show()
                }
            }

            // --- 4. PHONE CALL / DIALER ---
            command.contains("call") || command.contains("फोन") || command.contains("डायल") -> {
                speak("डायल पैड खोल रही हूँ")
                // Using ACTION_DIAL allows safe user confirmation
                val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:")
                }
                startActivity(dialIntent)
            }

            // --- 5. SEND SMS / MESSAGE ---
            command.contains("sms") || command.contains("मैसेज") || command.contains("संदेश") -> {
                speak("मैसेज भेजने के लिए संदेशवाहक खोल रही हूँ")
                val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:")
                    putExtra("sms_body", "नमस्ते!")
                }
                startActivity(smsIntent)
            }

            // --- 6. SETTINGS ---
            command.contains("settings") || command.contains("सेटिंग") -> {
                speak("सेटिंग्स खोल रही हूँ")
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }

            // --- 7. EXIT / CLOSE ---
            command.contains("बंद करो") || command.contains("exit") || command.contains("बाय") -> {
                speak("अलविदा, आपका दिन शुभ हो!")
                finish()
            }

            // --- 8. AI FALLBACK / GENERAL QUERY ---
            else -> {
                speak("मैंने सुना: $command. क्या आप दोबारा बोल सकते हैं या यूट्यूब, मैप, कैमरा बोलें?")
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
